async function loadFighters() {
  const res = await fetch('/api/fighters');
  const fighters = await res.json();

  const fighterHTML = fighters.map(f => {
    const healthPercent = Math.max(f.health, 0);
    return `
      <div class="fighter">
        <h3>${f.name}</h3>
        <div class="health-bar">
          <div class="health-fill" style="width: ${healthPercent}%;"></div>
        </div>
        <p>${f.health} HP - Special: ${f.specialMove}</p>
      </div>
    `;
  }).join('');

  document.getElementById('fighters').innerHTML = fighterHTML;

  const options = fighters.map(f =>
    `<option value="${f.name}">${f.name}</option>`
  ).join('');

  document.getElementById('attacker').innerHTML = options;
  document.getElementById('target').innerHTML = options;
}


async function attack() {
  const attacker = document.getElementById('attacker').value;
  const target = document.getElementById('target').value;
  const move = document.getElementById('move').value;

  const res = await fetch('/api/attack', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ attacker, target, move })
  });

  const result = await res.json();
  document.getElementById('result').innerText = result.message;
  loadFighters();
}

window.onload = loadFighters;
